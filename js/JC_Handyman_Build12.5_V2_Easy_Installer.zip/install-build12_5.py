from pathlib import Path
import shutil

ROOT=Path.cwd()
LINE='<script src="js/cloud-integration.js"></script>'
SKIP={"cloud-sync.html"}

def main():
    source=ROOT/"js"/"cloud-integration.js"
    if not source.exists():
        print("ERROR: js/cloud-integration.js is missing.")
        return

    changed=0
    print("\nInstalling Build 12.5 V2...\n")
    for path in sorted(ROOT.glob("*.html")):
        if path.name in SKIP:
            continue
        text=path.read_text(encoding="utf-8")
        if LINE in text:
            print(f"{path.name}: already installed")
            continue
        pos=text.lower().rfind("</body>")
        if pos==-1:
            print(f"{path.name}: skipped (no </body>)")
            continue
        backup=path.with_suffix(path.suffix+".build125-backup")
        if not backup.exists():
            shutil.copy2(path,backup)
        text=text[:pos]+"  "+LINE+"\n"+text[pos:]
        path.write_text(text,encoding="utf-8")
        changed+=1
        print(f"{path.name}: installed")

    print(f"\nFinished. {changed} page(s) updated.")
    print("Now run:")
    print("git add .")
    print('git commit -m "Install Build 12.5 cloud integration"')
    print("git push")

if __name__=="__main__":
    main()
