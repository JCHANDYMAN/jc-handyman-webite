JC HANDYMAN BUILD 12.5 V2 — EASY INSTALLER

This version avoids manually editing HTML files.

COPY THESE INTO THE MAIN PROJECT FOLDER:
- js/cloud-integration.js
- install-build12_5.py
- uninstall-build12_5.py

THEN RUN IN THE CODESPACES TERMINAL:

python3 install-build12_5.py

The installer automatically:
- finds your HTML pages
- skips cloud-sync.html
- makes backups
- adds the cloud integration line
- avoids duplicate installation

THEN PUBLISH:

git add .
git commit -m "Install Build 12.5 cloud integration"
git push

TO REMOVE IT LATER:

python3 uninstall-build12_5.py
