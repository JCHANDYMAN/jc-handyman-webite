from pathlib import Path
ROOT=Path.cwd()
LINE='<script src="js/cloud-integration.js"></script>'
count=0
for path in ROOT.glob("*.html"):
    text=path.read_text(encoding="utf-8")
    if LINE in text:
        text=text.replace("  "+LINE+"\n","").replace(LINE+"\n","").replace(LINE,"")
        path.write_text(text,encoding="utf-8")
        count+=1
        print(path.name+": removed")
print(f"Finished. Removed from {count} page(s).")
