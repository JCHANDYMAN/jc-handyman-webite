// JC Handyman CRM — Build 12.5 Cloud Integration
// Add this one file to each CRM page immediately before </body>:
// <script src="js/cloud-integration.js"></script>

(function (window, document) {
  "use strict";

  if (window.__JC_CLOUD_INTEGRATION_LOADED__) return;
  window.__JC_CLOUD_INTEGRATION_LOADED__ = true;

  const CDN_URL = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2";
  const SCRIPT_ELEMENT = document.currentScript;
  const SCRIPT_URL = SCRIPT_ELEMENT?.src || new URL("js/cloud-integration.js", document.baseURI).href;
  const SUPABASE_ENGINE_URL = new URL("supabase.js", SCRIPT_URL).href;

  const WATCHED_KEYS = [
    "jc_customers",
    "jc_properties",
    "jc_jobs",
    "jc_estimates",
    "jc_invoices",
    "jc_schedule",
    "jc_inspections",
    "jc_photo_docs",
    "jc_property_notes"
  ];

  const PULL_SESSION_KEY = "jc_cloud_integration_pulled";
  const LAST_PAGE_SYNC_KEY = "jc_cloud_integration_last_sync";
  const SNAPSHOT_INTERVAL_MS = 5000;
  const PERIODIC_SYNC_MS = 60000;
  const CHANGE_DEBOUNCE_MS = 1500;

  let lastSnapshot = "";
  let changeTimer = null;
  let periodicTimer = null;
  let snapshotTimer = null;
  let busy = false;
  let badge = null;

  function loadScript(src, id) {
    return new Promise((resolve, reject) => {
      const existing = id ? document.getElementById(id) : null;
      if (existing) {
        if (existing.dataset.loaded === "true") return resolve();
        existing.addEventListener("load", resolve, { once: true });
        existing.addEventListener("error", () => reject(new Error(`Unable to load ${src}`)), { once: true });
        return;
      }

      const script = document.createElement("script");
      if (id) script.id = id;
      script.src = src;
      script.async = false;
      script.addEventListener("load", () => {
        script.dataset.loaded = "true";
        resolve();
      }, { once: true });
      script.addEventListener("error", () => reject(new Error(`Unable to load ${src}`)), { once: true });
      document.head.appendChild(script);
    });
  }

  function makeBadge() {
    if (document.getElementById("jc-cloud-status-badge")) {
      badge = document.getElementById("jc-cloud-status-badge");
      return;
    }

    badge = document.createElement("button");
    badge.id = "jc-cloud-status-badge";
    badge.type = "button";
    badge.title = "Open JC Handyman Cloud Sync";
    badge.style.cssText = [
      "position:fixed",
      "right:14px",
      "bottom:14px",
      "z-index:99999",
      "border:1px solid #555",
      "border-radius:999px",
      "padding:8px 12px",
      "background:#1b1e24",
      "color:#fff",
      "font:700 12px Arial,sans-serif",
      "box-shadow:0 4px 18px rgba(0,0,0,.35)",
      "cursor:pointer"
    ].join(";");

    badge.addEventListener("click", () => {
      window.location.href = new URL("cloud-sync.html", document.baseURI).href;
    });

    document.body.appendChild(badge);
  }

  function setBadge(text, state = "neutral") {
    if (!badge) makeBadge();

    const colors = {
      online: "#39b978",
      syncing: "#f47b20",
      offline: "#d65757",
      signedout: "#d6a236",
      error: "#ff6b6b",
      neutral: "#aeb4c2"
    };

    badge.textContent = text;
    badge.style.borderColor = colors[state] || colors.neutral;
    badge.style.color = colors[state] || colors.neutral;
  }

  function safeRead(key) {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(value) ? value : [];
    } catch {
      return [];
    }
  }

  function snapshot() {
    return JSON.stringify(
      WATCHED_KEYS.map(key => [key, localStorage.getItem(key) || "[]"])
    );
  }

  function localRecordCount() {
    return WATCHED_KEYS.reduce((total, key) => total + safeRead(key).length, 0);
  }

  async function getUser() {
    try {
      return await window.JCCloud.getUser();
    } catch {
      return null;
    }
  }

  async function sync(reason = "automatic") {
    if (busy) return;
    if (!navigator.onLine) {
      setBadge("Cloud: Offline", "offline");
      return;
    }

    const user = await getUser();
    if (!user) {
      setBadge("Cloud: Sign in", "signedout");
      return;
    }

    busy = true;
    setBadge("Cloud: Syncing…", "syncing");

    try {
      const result = await window.JCCloud.syncNow();
      lastSnapshot = snapshot();
      localStorage.setItem(LAST_PAGE_SYNC_KEY, new Date().toISOString());
      setBadge("Cloud: Synced", "online");

      window.dispatchEvent(new CustomEvent("jc-cloud-page-synced", {
        detail: {
          reason,
          uploaded: result?.uploaded || 0,
          downloaded: result?.downloaded || 0,
          at: result?.at || new Date().toISOString()
        }
      }));
    } catch (error) {
      console.error("JC Cloud page sync failed:", error);
      setBadge("Cloud: Sync error", "error");
    } finally {
      busy = false;
    }
  }

  function scheduleSync(reason = "local change") {
    clearTimeout(changeTimer);
    changeTimer = setTimeout(() => sync(reason), CHANGE_DEBOUNCE_MS);
  }

  async function initialRestore() {
    const user = await getUser();

    if (!user) {
      setBadge("Cloud: Sign in", "signedout");
      return;
    }

    setBadge(navigator.onLine ? "Cloud: Connecting…" : "Cloud: Offline", navigator.onLine ? "syncing" : "offline");

    if (!navigator.onLine) return;

    const alreadyPulled = sessionStorage.getItem(PULL_SESSION_KEY) === "yes";

    try {
      if (!alreadyPulled) {
        await window.JCCloud.pullCloud();
        sessionStorage.setItem(PULL_SESSION_KEY, "yes");
      }

      lastSnapshot = snapshot();
      setBadge("Cloud: Synced", "online");

      // Push local records too, so a newly-created local record is not missed.
      if (localRecordCount() > 0) {
        scheduleSync("page startup");
      }
    } catch (error) {
      console.error("JC Cloud initial restore failed:", error);
      setBadge("Cloud: Sync error", "error");
    }
  }

  function beginWatching() {
    lastSnapshot = snapshot();

    snapshotTimer = setInterval(() => {
      const next = snapshot();
      if (next !== lastSnapshot) {
        lastSnapshot = next;
        scheduleSync("local record changed");
      }
    }, SNAPSHOT_INTERVAL_MS);

    periodicTimer = setInterval(() => {
      sync("periodic check");
    }, PERIODIC_SYNC_MS);

    window.addEventListener("storage", event => {
      if (WATCHED_KEYS.includes(event.key)) scheduleSync("another tab changed data");
    });

    window.addEventListener("online", () => {
      setBadge("Cloud: Back online", "syncing");
      scheduleSync("internet restored");
    });

    window.addEventListener("offline", () => {
      setBadge("Cloud: Offline", "offline");
    });

    window.addEventListener("focus", () => {
      const next = snapshot();
      if (next !== lastSnapshot) {
        lastSnapshot = next;
        scheduleSync("page focused");
      }
    });
  }

  async function start() {
    makeBadge();
    setBadge("Cloud: Loading…", "neutral");

    try {
      if (!window.supabase?.createClient) {
        await loadScript(CDN_URL, "jc-supabase-cdn");
      }

      if (!window.JCCloud) {
        await loadScript(SUPABASE_ENGINE_URL, "jc-supabase-engine");
      }

      if (!window.JCCloud) {
        throw new Error("JCCloud was not created by js/supabase.js");
      }

      beginWatching();
      await initialRestore();
    } catch (error) {
      console.error("JC Cloud Integration failed:", error);
      setBadge("Cloud: Load error", "error");
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }

  window.addEventListener("beforeunload", () => {
    clearInterval(snapshotTimer);
    clearInterval(periodicTimer);
    clearTimeout(changeTimer);
  });
})(window, document);
