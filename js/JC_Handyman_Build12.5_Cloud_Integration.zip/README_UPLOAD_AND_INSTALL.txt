JC HANDYMAN BUILD 12.5 — CLOUD INTEGRATION

PURPOSE
Build 12.5 connects every CRM page to the working Build 12.2 cloud system.

UPLOAD THIS ONE NEW FILE
- js/cloud-integration.js -> your existing js folder

DO NOT REPLACE
- js/supabase.js
- js/cloud-sync-page.js
- cloud-sync.html
- any existing CRM page yet

THEN ADD ONE LINE TO EACH CRM PAGE
Place this immediately before the closing </body> tag:

<script src="js/cloud-integration.js"></script>

ADD IT TO THESE PAGES
- dashboard.html
- customers.html
- properties.html
- jobs.html
- estimates.html
- invoices.html
- scheduler.html
- photo-center.html
- property-history.html
- inspection-center.html
- business-dashboard.html

DO NOT ADD IT TO
- cloud-sync.html
That page already loads the Supabase files directly.

WHAT IT DOES
- Loads the Supabase browser library automatically.
- Loads your working js/supabase.js engine automatically.
- Restores cloud records when a CRM page opens.
- Watches customers, properties, jobs, estimates, invoices, schedule,
  inspections, photo/document records, and property notes.
- Starts a cloud sync when local records change.
- Runs another sync approximately once per minute.
- Syncs when the internet connection returns.
- Keeps all localStorage data available while offline.
- Displays a small Cloud status button in the bottom-right corner.
- Clicking the status button opens cloud-sync.html.

IMPORTANT
You must already be signed in through cloud-sync.html.
Supabase keeps the browser session in local storage, so the same signed-in
session is used on the other CRM pages.

TEST
1. Upload js/cloud-integration.js.
2. Add the one-line script to customers.html first.
3. Commit the changes and wait for GitHub Pages to update.
4. Press Ctrl+F5 on customers.html.
5. Add a test customer.
6. Wait about 5-10 seconds.
7. Open cloud-sync.html and confirm the cloud record count increased.
8. Once confirmed, add the script line to the remaining CRM pages.

ROLLBACK
Remove this line from a page:
<script src="js/cloud-integration.js"></script>

Removing the line does not delete local or cloud data.
